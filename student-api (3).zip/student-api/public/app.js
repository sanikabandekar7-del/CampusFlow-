
"use strict";

// CampusFlow frontend connected to the existing Express API.
const API_URL = "/api";

const state = {
  token: localStorage.getItem("campusflowToken") || "",
  user: JSON.parse(localStorage.getItem("campusflowUser") || "null"),
  students: [],
  editingId: null,
  authMode: "login",
  currentPage: "overview"
};

const $ = (selector) => document.querySelector(selector);

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

function initials(name) {
  return String(name || "Student")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0] || "")
    .join("")
    .toUpperCase();
}

function showToast(message, isError = false) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("show");

  clearTimeout(showToast.timeout);
  showToast.timeout = setTimeout(() => {
    toast.classList.remove("show");
  }, 3200);
}

function setFormMessage(selector, message, type = "") {
  const element = $(selector);
  element.textContent = message;
  element.className = `form-message ${type}`.trim();
}

function setButtonLoading(button, loading, loadingText, originalText) {
  button.disabled = loading;
  button.textContent = loading ? loadingText : originalText;
}

function openModal(id) {
  const modal = document.getElementById(id);
  modal.hidden = false;

  const firstInput = modal.querySelector("input:not([hidden])");
  if (firstInput) setTimeout(() => firstInput.focus(), 50);
}

function closeModal(id) {
  document.getElementById(id).hidden = true;
}

async function apiRequest(path, options = {}) {
  const headers = {
    ...(options.body ? { "Content-Type": "application/json" } : {}),
    ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
    ...options.headers
  };

  let response;

  try {
    response = await fetch(`${API_URL}${path}`, {
      ...options,
      headers
    });
  } catch {
    $("#apiStatus").textContent = "Offline";
    $("#apiCaption").textContent = "Could not reach the Express server";
    throw new Error("Cannot connect to the server. Check that node server.js is running.");
  }

  // Even an authentication error means the server responded.
  $("#apiStatus").textContent = "Online";
  $("#apiCaption").textContent = "Express server responded successfully";

  const contentType = response.headers.get("content-type") || "";
  let result = {};

  if (contentType.includes("application/json")) {
    result = await response.json();
  }

  if (response.status === 401 && state.token) {
    clearSession(false);
  }

  if (!response.ok) {
    throw new Error(result.message || `Request failed (${response.status}).`);
  }

  return result;
}

function clearSession(showMessage = true) {
  state.token = "";
  state.user = null;

  localStorage.removeItem("campusflowToken");
  localStorage.removeItem("campusflowUser");

  updateSessionUI();

  if (showMessage) {
    showToast("You have been logged out.");
  }
}

function updateSessionUI() {
  const loggedIn = Boolean(state.token && state.user);

  $("#authButton").textContent = loggedIn ? "Log out" : "Log in";
  $("#userAvatar").textContent = loggedIn
    ? initials(state.user.name || state.user.email)
    : "G";

  $("#sessionStatus").textContent = loggedIn
    ? (state.user.role === "admin" ? "Admin" : "Logged in")
    : "Guest";

  $("#sessionCaption").textContent = loggedIn
    ? state.user.email
    : "Log in to manage records";

  $("#addStudentButton").disabled = false;
  $("#overviewAddButton").disabled = false;

  $("#navStudentCount").textContent = state.students.length;
}

function goToPage(page) {
  const pageNames = {
    overview: "Overview",
    students: "Students",
    tasks: "Project milestones"
  };

  if (!pageNames[page]) return;

  state.currentPage = page;

  document.querySelectorAll(".page-view").forEach((view) => {
    view.classList.toggle("active", view.id === `${page}Page`);
  });

  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.toggle("active", link.dataset.page === page);
  });

  $("#breadcrumbPage").textContent = pageNames[page];
  $("#sidebar").classList.remove("open");

  if (page === "students") {
    renderStudents();
  }
}

function showGuestStudentMessage() {
  $("#studentsTableBody").innerHTML = `
    <tr>
      <td colspan="4" class="table-message">
        Log in to view student records from your database.
      </td>
    </tr>`;

  $("#directorySummary").textContent = "Login required";
  $("#tableFooterText").textContent = "Your records are protected by JWT authentication";
}

function renderStudents() {
  const query = $("#studentSearch").value.trim().toLowerCase();

  if (!state.token) {
    showGuestStudentMessage();
    return;
  }

  const filtered = state.students.filter((student) => {
    return String(student.name || "").toLowerCase().includes(query) ||
      String(student.course || "").toLowerCase().includes(query) ||
      String(student.id || "").includes(query);
  });

  $("#directorySummary").textContent =
    `${filtered.length} ${filtered.length === 1 ? "record" : "records"} found`;

  $("#tableFooterText").textContent =
    `${filtered.length} of ${state.students.length} records shown`;

  if (filtered.length === 0) {
    $("#studentsTableBody").innerHTML = `
      <tr>
        <td colspan="4" class="table-message">
          ${state.students.length === 0
            ? "No student records found. Add your first student."
            : "No students match your search."}
        </td>
      </tr>`;
    return;
  }

  $("#studentsTableBody").innerHTML = filtered.map((student) => {
    const id = Number(student.id);
    const name = escapeHTML(student.name);
    const course = escapeHTML(student.course);

    const actions = `
      <div class="action-group">
        <button class="icon-button" data-action="edit" data-id="${id}"
          title="Edit student" aria-label="Edit ${name}">✎</button>
        ${state.user?.role === "admin" ? `
          <button class="icon-button delete" data-action="delete" data-id="${id}"
            title="Delete student" aria-label="Delete ${name}">×</button>
        ` : ""}
      </div>`;

    return `
      <tr>
        <td>
          <div class="student-cell">
            <span class="person-avatar">${escapeHTML(initials(student.name))}</span>
            <span class="student-name">${name}</span>
          </div>
        </td>
        <td><span class="course-pill" title="${course}">${course}</span></td>
        <td><span class="record-id">#${id}</span></td>
        <td>${actions}</td>
      </tr>`;
  }).join("");
}

function renderRecentStudents() {
  const recent = [...state.students].slice(-5).reverse();

  $("#totalStudents").textContent = state.students.length;
  $("#navStudentCount").textContent = state.students.length;

  if (!state.token) {
    $("#recentStudents").innerHTML = `
      <div class="empty-state">Log in to load your database records.</div>`;
    return;
  }

  if (recent.length === 0) {
    $("#recentStudents").innerHTML = `
      <div class="empty-state">No student records yet. Add your first student.</div>`;
    return;
  }

  $("#recentStudents").innerHTML = recent.map((student) => `
    <div class="recent-row">
      <span class="person-avatar">${escapeHTML(initials(student.name))}</span>
      <div class="person-info">
        <strong>${escapeHTML(student.name)}</strong>
        <span>${escapeHTML(student.course)}</span>
      </div>
      <span class="record-id">#${Number(student.id)}</span>
    </div>
  `).join("");
}

async function loadStudents() {
  if (!state.token) {
    state.students = [];
    $("#totalStudents").textContent = "—";
    $("#apiStatus").textContent = "Checking";
    $("#apiCaption").textContent = "Checking Express server";
    renderRecentStudents();
    renderStudents();
    updateSessionUI();

    // Check that the server is reachable without accessing protected data.
    try {
      await fetch("/", { method: "GET" });
      $("#apiStatus").textContent = "Online";
      $("#apiCaption").textContent = "Website served by Express";
    } catch {
      $("#apiStatus").textContent = "Offline";
      $("#apiCaption").textContent = "Start your Express server";
    }
    return;
  }

  $("#studentsTableBody").innerHTML = `
    <tr><td colspan="4" class="table-message">Loading student records…</td></tr>`;

  try {
    const result = await apiRequest("/students");
    state.students = Array.isArray(result.data) ? result.data : [];

    renderRecentStudents();
    renderStudents();
    updateSessionUI();
  } catch (error) {
    state.students = [];
    renderRecentStudents();
    $("#studentsTableBody").innerHTML = `
      <tr><td colspan="4" class="table-message">${escapeHTML(error.message)}</td></tr>`;
    $("#directorySummary").textContent = "Could not load records";
    $("#tableFooterText").textContent = "Check the server and database";
    showToast(error.message, true);
  }
}

function setAuthMode(mode) {
  state.authMode = mode;
  const registering = mode === "register";

  document.querySelectorAll("[data-auth-mode]").forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.authMode === mode);
  });

  $("#authTitle").textContent = registering
    ? "Create your account."
    : "Good to have you here.";

  $("#authDescription").textContent = registering
    ? "Register to start managing your student records."
    : "Log in to manage your student records.";

  $("#authName").hidden = !registering;
  $("#authNameLabel").hidden = !registering;
  $("#authName").required = registering;
  $("#authPassword").autocomplete = registering ? "new-password" : "current-password";
  $("#authHint").textContent = registering
    ? "Use a valid email and a password between 8 and 72 characters."
    : "Use your registered email and password.";

  $("#authSubmit").textContent = registering ? "Create account →" : "Log in →";
  setFormMessage("#authMessage", "");
}

async function handleAuthSubmit(event) {
  event.preventDefault();

  const button = $("#authSubmit");
  const originalText = state.authMode === "register" ? "Create account →" : "Log in →";
  const payload = {
    email: $("#authEmail").value.trim(),
    password: $("#authPassword").value
  };

  if (state.authMode === "register") {
    payload.name = $("#authName").value.trim();
  }

  setButtonLoading(button, true, "Please wait…", originalText);
  setFormMessage("#authMessage", "");

  try {
    const endpoint = state.authMode === "register" ? "/auth/register" : "/auth/login";
    const result = await apiRequest(endpoint, {
      method: "POST",
      body: JSON.stringify(payload)
    });

    if (state.authMode === "register") {
      setAuthMode("login");
      $("#authEmail").value = payload.email;
      $("#authPassword").value = "";
      setFormMessage(
        "#authMessage",
        "Account created. Log in with your new credentials.",
        "success"
      );
      showToast("Account created successfully.");
      return;
    }

    if (!result.token || !result.user) {
      throw new Error("The login response did not contain a token and user.");
    }

    state.token = result.token;
    state.user = result.user;

    localStorage.setItem("campusflowToken", state.token);
    localStorage.setItem("campusflowUser", JSON.stringify(state.user));

    closeModal("authModal");
    $("#authForm").reset();
    updateSessionUI();

    showToast(`Welcome, ${state.user.name || state.user.email}!`);
    await loadStudents();
  } catch (error) {
    setFormMessage("#authMessage", error.message, "error");
  } finally {
    setButtonLoading(button, false, "", originalText);
  }
}


async function handleAdminLoginSubmit(event) {
  event.preventDefault();

  const button = $("#adminLoginSubmit");
  const originalText = "Admin Login →";
  const email = $("#adminEmail").value.trim();
  const password = $("#adminPassword").value;

  setButtonLoading(button, true, "Verifying…", originalText);
  setFormMessage("#adminLoginMessage", "");

  try {
    const result = await apiRequest("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });

    if (!result.token || !result.user) {
      throw new Error("The login response did not contain a token and user.");
    }

    if (result.user.role !== "admin") {
      setFormMessage(
        "#adminLoginMessage",
        "This account is not an administrator. Use an admin account or return to user login.",
        "error"
      );
      return;
    }

    state.token = result.token;
    state.user = result.user;
    localStorage.setItem("campusflowToken", state.token);
    localStorage.setItem("campusflowUser", JSON.stringify(state.user));

    closeModal("adminLoginModal");
    $("#adminLoginForm").reset();
    updateSessionUI();
    showToast(`Administrator access granted. Welcome, ${state.user.name || state.user.email}!`);
    await loadStudents();
  } catch (error) {
    setFormMessage("#adminLoginMessage", error.message, "error");
  } finally {
    setButtonLoading(button, false, "", originalText);
  }
}

function openStudentForm(student = null) {
  if (!state.token || !state.user) {
    showToast("Please log in to add a student.", true);
    setAuthMode("login");
    openModal("authModal");
    return;
  }

  state.editingId = student ? Number(student.id) : null;

  $("#studentModalTitle").textContent = student
    ? "Edit student"
    : "Add a student";

  $("#saveStudentButton").textContent = student
    ? "Save changes"
    : "Save student";

  $("#studentName").value = student?.name || "";
  $("#studentCourse").value = student?.course || "";


  setFormMessage("#studentFormMessage", "");
  openModal("studentModal");
}

async function handleStudentSubmit(event) {
  event.preventDefault();

  if (!state.token) {
    showToast("Please log in first.", true);
    closeModal("studentModal");
    openModal("authModal");
    return;
  }

  const name = $("#studentName").value.trim();
  const course = $("#studentCourse").value.trim();

  if (name.length < 2 || name.length > 100) {
    setFormMessage("#studentFormMessage", "Name must contain 2 to 100 characters.", "error");
    return;
  }

  if (course.length < 2 || course.length > 100) {
    setFormMessage("#studentFormMessage", "Course must contain 2 to 100 characters.", "error");
    return;
  }

  const editingId = state.editingId;
  const button = $("#saveStudentButton");
  const originalText = editingId ? "Save changes" : "Save student";
  const endpoint = editingId ? `/students/${editingId}` : "/students";
  const method = editingId ? "PUT" : "POST";

  setButtonLoading(button, true, "Saving…", originalText);
  setFormMessage("#studentFormMessage", "");

  try {
    const result = await apiRequest(endpoint, {
      method,
      body: JSON.stringify({ name, course })
    });

    closeModal("studentModal");
    $("#studentForm").reset();

    showToast(result.message || (editingId ? "Student updated." : "Student added."));
    await loadStudents();
  } catch (error) {
    setFormMessage("#studentFormMessage", error.message, "error");
  } finally {
    setButtonLoading(button, false, "", originalText);
  }
}

async function deleteStudent(id) {
  if (state.user?.role !== "admin") {
    showToast("Only administrators can delete student records.", true);
    return;
  }

  const student = state.students.find((item) => Number(item.id) === Number(id));
  if (!student) return;

  const confirmed = window.confirm(
    `Delete "${student.name}" from the database?\n\nThis action cannot be undone.`
  );

  if (!confirmed) return;

  try {
    const result = await apiRequest(`/students/${id}`, {
      method: "DELETE"
    });

    showToast(result.message || "Student deleted.");
    await loadStudents();
  } catch (error) {
    showToast(error.message, true);
  }
}

// Navigation
document.querySelectorAll("[data-page]").forEach((button) => {
  button.addEventListener("click", () => goToPage(button.dataset.page));
});

document.querySelectorAll("[data-go]").forEach((button) => {
  button.addEventListener("click", () => goToPage(button.dataset.go));
});

$("#menuToggle").addEventListener("click", () => {
  $("#sidebar").classList.toggle("open");
});

// Authentication
$("#authButton").addEventListener("click", () => {
  if (state.token) {
    const confirmed = window.confirm("Log out of CampusFlow?");
    if (confirmed) clearSession();
    return;
  }

  setAuthMode("login");
  openModal("authModal");
});

document.querySelectorAll("[data-auth-mode]").forEach((tab) => {
  tab.addEventListener("click", () => setAuthMode(tab.dataset.authMode));
});

$("#authForm").addEventListener("submit", handleAuthSubmit);

$("#adminLoginButton").addEventListener("click", () => {
  closeModal("authModal");
  $("#adminLoginForm").reset();
  setFormMessage("#adminLoginMessage", "");
  openModal("adminLoginModal");
});

$("#adminLoginForm").addEventListener("submit", handleAdminLoginSubmit);

$("#backToUserLogin").addEventListener("click", () => {
  closeModal("adminLoginModal");
  setAuthMode("login");
  openModal("authModal");
});

// Student management
$("#addStudentButton").addEventListener("click", () => openStudentForm());
$("#overviewAddButton").addEventListener("click", () => openStudentForm());
$("#studentForm").addEventListener("submit", handleStudentSubmit);
$("#studentSearch").addEventListener("input", renderStudents);
$("#refreshButton").addEventListener("click", loadStudents);

$("#studentsTableBody").addEventListener("click", (event) => {
  const button = event.target.closest("[data-action]");
  if (!button) return;

  const id = Number(button.dataset.id);
  const action = button.dataset.action;

  if (action === "edit") {
    const student = state.students.find((item) => Number(item.id) === id);
    if (student) openStudentForm(student);
  }

  if (action === "delete") {
    deleteStudent(id);
  }
});

// Modal close buttons and clicking outside the dialog
document.querySelectorAll("[data-close]").forEach((button) => {
  button.addEventListener("click", () => closeModal(button.dataset.close));
});

document.querySelectorAll(".modal-backdrop").forEach((backdrop) => {
  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) closeModal(backdrop.id);
  });
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    document.querySelectorAll(".modal-backdrop:not([hidden])").forEach((modal) => {
      closeModal(modal.id);
    });
    $("#sidebar").classList.remove("open");
  }
});

// Initialize the interface.
updateSessionUI();
goToPage("overview");
loadStudents();
